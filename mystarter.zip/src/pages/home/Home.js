const Home=()=>{
    return(
        <>
        {/* <h2 style={{marginRight:"300px"}}>Home Page</h2> */}
        </>
    )
}
export default Home;