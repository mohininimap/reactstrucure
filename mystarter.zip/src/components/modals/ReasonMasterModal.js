import React from 'react'

const ReasonMasterModal = () => {
  return (
    <div>ReasonMasterModal</div>
  )
}

export default ReasonMasterModal